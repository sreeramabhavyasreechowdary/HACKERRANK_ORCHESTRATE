"""Evidence extraction package."""
